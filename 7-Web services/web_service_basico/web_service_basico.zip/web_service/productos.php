<?php

	$GLOBALS['conexion'] = mysqli_connect('localhost','root','','web_service');
	switch ($_GET['accion']) {
	case 'consulta':
		$sql = 'SELECT * FROM productos ORDER BY nombre';
		$resultado = $GLOBALS['conexion'] -> query($sql);
		while ($linea = $resultado -> fetch_array()) {
			echo $linea['id'];
			echo ',';
			echo $linea['nombre'];
			echo "\n";
		}
		break;
	case 'insercion':
		$sql = 'INSERT INTO productos (nombre) VALUES (\'' . addslashes($_GET['valor']) . '\')';
		$GLOBALS['conexion'] -> query($sql);
		break;
	case 'eliminacion':
		$sql = 'DELETE FROM productos WHERE id = ' . (int)$_GET['id'];
		$GLOBALS['conexion'] -> query($sql);
	}

?>