<?php

	switch ($_POST['acc']) {
	case 'insertar':
		file_get_contents('http://localhost/web_service/productos.php?accion=insercion&valor=' . urlencode($_POST['nombre']));
		break;
	case 'eliminar':
		file_get_contents('http://localhost/web_service/productos.php?accion=eliminacion&id=' . (int)$_POST['id']);
		break;
	}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Llamada a web service</title>
		<link href="estilos.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<div id="main">
			<header>
				<h1>Llamada a web service</h1>
			</header>
			<div id="contenido">
				<h2>Productos</h2>
<?php

	$datos = file_get_contents('http://localhost/web_service/productos.php?accion=consulta');
	$datos_f = explode("\n",$datos);
	$j = 0;
	for ($i=0;$i<count($datos_f);$i++) {
		if ($datos_f[$i] != '') {
			$linea = explode(',',$datos_f[$i]);
			$productos[$j]['id'] = $linea[0];
			$productos[$j]['nombre'] = $linea[1];
			$j++;
		}
	}
	for ($i=0;$i<count($productos);$i++) {
?>
				<div class="prod_nombre">
				<?php echo htmlentities($productos[$i]['nombre']); ?>
				</div>
				<div class="prod_eliminar">
					<form method="post" action="index.php">
						<input type="hidden" name="acc" value="eliminar">
						<input type="hidden" name="id" value="<?php echo $productos[$i]['id']; ?>">
						<button type="submit">Eliminar</button>
					</form>
				</div>
<?php
	}
?>
				<h2>Añadir producto</h2>
				<form method="post" action="index.php">
					<input type="hidden" name="acc" value="insertar">
					<input type="text" name="nombre">
					<button type="submit">Añadir</button>
				</form>
			</div>
		</div>
	</body>
</html>